namespace LAB4Encapsulation
{
    public partial class Form1 : Form
    {
        Classroom classroom;
        public Form1()
        {
            InitializeComponent();
            classroom = new Classroom("OOP");
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string input_name = this.tbName.Text;
            string input_year = this.tbBirthYear.Text;
            int iYear = Int32.Parse(input_year);
            //create object from Person class
            Person person = new Person(input_name, iYear);
            this.classroom.addPerson2Class(person);
            //display person
            this.tbListofPerson.Text = 
                this.classroom.showAllPersoninClass();
            //display total age of class
            this.tbTotal.Text = "";
        }
    }
}